# Best-Deals
E commerce website like best buy. Developed using JSP and servlets



How to run:
Install apache-tomcat-7.0.34
Paste all these files in a folder called BestDeals inside C:\apache-tomcat-7.0.34\webapps\
Open cmd:
go to C:\apache-tomcat-7.0.34\bin
type startup.bat
then go to your browser and type localhost\BestDeals
Use the website


**Feel free to implement or change and create a pull request**
